# MarketMinds — Financial Literacy Investing Simulator (MVP starter)

A responsive React/Vite practice simulator based on the supplied PRD. It runs immediately in **demo mode** with virtual cash, asset selection, buy/sell checks, portfolio view, a replay timeline, learning cards, and competition/leaderboard previews.

> **Important demo limitation:** the built-in prices and names are illustrative placeholder data, not verified historical NSE/BSE prices. The UI is not production-ready for real student accounts or competitions until the Supabase + historical-data steps below are completed. Do not present demo returns as real market results.

## 1. Run it locally

1. Install Node.js 20+ (LTS) from https://nodejs.org.
2. Unzip this folder and open a terminal inside `financial-literacy-simulator`.
3. Run:
   ```bash
   npm install
   npm run dev
   ```
4. Open the localhost URL Vite prints (usually `http://localhost:5173`).
5. Build check: `npm run build`.

The simulator works in local demo mode without credentials. This build is a frontend MVP; Supabase Auth, database persistence, and TinyFish ingestion are integration steps, not active in demo mode.

## 2. Create Supabase project and connect the frontend

1. Go to https://supabase.com, create a project, and keep its database password safe.
2. In **Project Settings → API**, copy the Project URL and `anon` / publishable key.
3. In this project, copy `.env.example` to `.env.local` and fill:
   ```env
   VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
   ```
4. Restart `npm run dev`. Never use the `service_role` key in a `VITE_` variable or in frontend code. The service role bypasses RLS.

The Supabase client is initialized in `src/main.jsx`; the demo UI remains local until you wire the auth and database calls described below.

## 3. Create the MVP database schema

In Supabase **SQL Editor → New query**, run this SQL. Review it with your team before production, especially age/consent requirements and privacy policy.

```sql
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  full_name text,
  date_of_birth date,
  parental_consent_status text not null default 'not_required'
    check (parental_consent_status in ('pending','approved','declined','not_required')),
  starting_balance numeric(14,2) not null default 10000
    check (starting_balance between 1000 and 50000),
  bonus_balance numeric(14,2) not null default 0,
  created_at timestamptz not null default now()
);

create table public.assets (
  id bigint generated always as identity primary key,
  symbol text not null unique,
  company_name text not null,
  sector text,
  exchange text not null default 'NSE',
  is_active boolean not null default true
);

create table public.price_history (
  asset_id bigint not null references public.assets(id) on delete cascade,
  trade_date date not null,
  open numeric(14,4), high numeric(14,4), low numeric(14,4),
  close numeric(14,4), adjusted_close numeric(14,4), volume bigint,
  source text not null,
  fetched_at timestamptz not null default now(),
  primary key(asset_id, trade_date),
  check (close is null or close > 0)
);

create table public.simulations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  seed bigint not null,
  window_start date,
  window_end date,
  starting_cash numeric(14,2) not null,
  cash numeric(14,2) not null,
  status text not null default 'active' check(status in ('active','completed')),
  simulated_day integer not null default 0,
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  final_value numeric(14,2)
);

create table public.trades (
  id uuid primary key default gen_random_uuid(),
  simulation_id uuid not null references public.simulations(id) on delete cascade,
  asset_id bigint not null references public.assets(id),
  side text not null check(side in ('buy','sell')),
  quantity integer not null check(quantity > 0),
  price numeric(14,4) not null check(price > 0),
  sim_date date not null,
  created_at timestamptz not null default now()
);

create table public.holdings (
  simulation_id uuid not null references public.simulations(id) on delete cascade,
  asset_id bigint not null references public.assets(id),
  quantity integer not null default 0 check(quantity >= 0),
  avg_cost numeric(14,4) not null default 0,
  primary key(simulation_id, asset_id)
);

alter table public.profiles enable row level security;
alter table public.simulations enable row level security;
alter table public.trades enable row level security;
alter table public.holdings enable row level security;
-- Users can view/update their own profile. Add stricter column-level handling
-- for DOB, consent, and starting_balance before launch.
create policy "profile owner read" on public.profiles for select
  using (auth.uid() = id);
create policy "profile owner insert" on public.profiles for insert
  with check (auth.uid() = id);
create policy "profile owner update" on public.profiles for update
  using (auth.uid() = id) with check (auth.uid() = id);
create policy "simulation owner read" on public.simulations for select
  using (auth.uid() = user_id);
create policy "simulation owner insert" on public.simulations for insert
  with check (auth.uid() = user_id);
create policy "simulation owner update" on public.simulations for update
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "trade owner read" on public.trades for select
  using (exists (select 1 from public.simulations s where s.id=simulation_id and s.user_id=auth.uid()));
create policy "holding owner read" on public.holdings for select
  using (exists (select 1 from public.simulations s where s.id=simulation_id and s.user_id=auth.uid()));

-- Public stock catalogue/history is read-only to signed-in users.
alter table public.assets enable row level security;
alter table public.price_history enable row level security;
create policy "assets readable" on public.assets for select using (true);
create policy "prices readable" on public.price_history for select using (true);
```

**Security note:** this starter SQL intentionally does not expose trade/holding insert/update policies to clients. For a real app, implement a server-side Edge Function/RPC that validates current replay day, available cash, holdings, and price, then writes the trade and portfolio atomically. Do not trust browser-supplied price or competition score. Add parental-consent tables/workflow and appropriate privacy/legal review before onboarding minors.

## 4. Turn on Supabase Auth

1. In Supabase **Authentication → Providers**, enable Email. Set your site URL and local redirect URL (for example `http://localhost:5173`).
2. In the signup form, call `supabase.auth.signUp({ email, password, options: { data: { full_name, username, date_of_birth }}})`; use email verification.
3. After verification/login, create the profile row with the new auth user ID and the selected starting balance. Validate username uniqueness on the server/database.
4. Add login with `supabase.auth.signInWithPassword({email,password})`, password reset with `supabase.auth.resetPasswordForEmail(email)`, and logout with `supabase.auth.signOut()`.
5. Protect app routes by checking `supabase.auth.getSession()` and subscribing to `supabase.auth.onAuthStateChange`. For users below the PRD's consent threshold, keep simulator/competition access blocked until guardian consent is recorded. The PRD's age/consent threshold needs legal confirmation before launch.

Example profile creation after signup (adapt your form names):
```js
const { data, error } = await supabase.auth.signUp({
  email, password,
  options: { data: { full_name: name, username, date_of_birth: dob } }
});
if (error) throw error;
if (data.user) {
  const { error: profileError } = await supabase.from('profiles').insert({
    id: data.user.id, full_name: name, username, date_of_birth: dob,
    starting_balance: selectedStartingMoney
  });
  if (profileError) throw profileError;
}
```

For production, do not rely on a client-side age calculation or a profile row the user can edit to bypass consent. Use a trusted server function, and tighten profile column permissions/policies so starting balance and DOB cannot be arbitrarily changed after signup.

## 5. TinyFish historical-data ingestion (server-only)

The PRD calls for a back-office/admin-started or scheduled data pipeline. Users must never trigger TinyFish, and the TinyFish key must never reach the browser.

1. Confirm a permitted historical-data source and its terms. Prefer official exchange/download sources where possible. TinyFish extraction does not itself grant rights to reuse market data.
2. In TinyFish, test a single symbol/date range. The PRD names the Agent streaming endpoint `https://agent.tinyfish.ai/v1/automation/run-sse`; consult your current TinyFish dashboard/docs for required request fields and response/event format before deploying because API schemas can change.
3. Create a Supabase Edge Function named `collect-history`. Add your secret in Supabase, not `.env.local`:
   ```bash
   supabase secrets set TINYFISH_API_KEY=your_key
   supabase secrets set TINYFISH_AGENT_URL=https://agent.tinyfish.ai/v1/automation/run-sse
   ```
4. Deploy the Edge Function. It should accept an admin-only request with symbol, source URL, and date range; call TinyFish; persist the raw response/source URL/run ID; validate rows; then upsert cleaned prices into `price_history`.
5. First run on only three stocks. Inspect every returned date/price against a second source. Flag missing days, zero/negative prices, and unusual jumps. Retry a failed stock no more than twice, as in the PRD.
6. Schedule monthly refreshes for missing dates. Only an admin/cron job should invoke ingestion.

A **safe skeleton** is in `supabase/functions/collect-history/index.ts`. It deliberately returns a 501 until you adapt the current TinyFish request/stream parser and add an admin authorization check. Do not deploy it as a functioning collector without those steps.

## 6. Replace demo assets with real replay data

- Seed `assets` with the selected 10–15 NSE/BSE stocks and verified metadata.
- Populate `price_history` with validated, split/bonus-adjusted daily data and source metadata.
- Build a server-side session-creation function that uses a deterministic seeded RNG to choose assets and a period containing up/down phases. Store seed/window in `simulations`.
- During play, query only dates up to the session's current simulated day. Do not send future prices to the client.
- Hide ticker/date mappings until session completion, as specified in the PRD. The frontend currently shows placeholder names and must be updated to use Stock A/Day 1 labels in a production replay.
- Calculate portfolio value, return, max drawdown, best/worst trade, and benchmark on the server when the session ends.

## 7. Build/launch checklist

- [ ] Replace placeholder demo market with validated historical data.
- [ ] Implement and test server-validated atomic buy/sell function.
- [ ] Complete auth, email verification, password reset, session protection.
- [ ] Confirm minor consent/privacy requirements with qualified counsel.
- [ ] Apply RLS to every table and test with two different user accounts.
- [ ] Server-validate seeded competition outcomes; one entry/user; no result edits after submit.
- [ ] Ensure TinyFish secret is only in Supabase secrets; never in frontend env.
- [ ] Add accessible labels, keyboard/touch tests, and mobile QA.
- [ ] Clearly state “practice only; past performance does not predict future results.”
