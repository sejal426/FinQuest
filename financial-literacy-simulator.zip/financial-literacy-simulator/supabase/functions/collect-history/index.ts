// Supabase Edge Function starter — not production-ready until TinyFish response
// parsing and admin authorization are implemented and tested.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  // TODO: Verify caller is an authorized admin (JWT + role table/claim).
  // Do not expose this endpoint to ordinary signed-in users.
  const tinyfishKey = Deno.env.get("TINYFISH_API_KEY");
  const tinyfishUrl = Deno.env.get("TINYFISH_AGENT_URL");
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!tinyfishKey || !tinyfishUrl || !supabaseUrl || !serviceRole) {
    return new Response(JSON.stringify({ error: "Missing server secrets" }), {
      status: 500, headers: { "content-type": "application/json" }
    });
  }

  const { symbol, sourceUrl, from, to } = await req.json();
  if (![symbol, sourceUrl, from, to].every((v) => typeof v === "string" && v.length > 0)) {
    return new Response(JSON.stringify({ error: "symbol, sourceUrl, from, and to are required" }), { status: 400 });
  }

  // IMPORTANT: confirm the current TinyFish Agent API request and SSE format in
  // TinyFish docs. The exact body/event parser is intentionally left as TODO.
  // Keep the key server-side and never return it to the caller.
  const tinyfishResponse = await fetch(tinyfishUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-API-Key": tinyfishKey },
    body: JSON.stringify({
      goal: `Extract historical daily OHLCV rows for ${symbol} from ${sourceUrl} between ${from} and ${to}. Return JSON rows with date, open, high, low, close, volume.`,
    })
  });
  const rawText = await tinyfishResponse.text();
  if (!tinyfishResponse.ok) {
    return new Response(JSON.stringify({ error: "TinyFish request failed", status: tinyfishResponse.status }), { status: 502 });
  }

  // TODO: Parse TinyFish SSE into structured rows. Validate dates, positive
  // prices, missing sessions, duplicate rows, and suspicious jumps; compare
  // samples against a second source. Store rawText + sourceUrl + run_id in
  // raw_price_imports, then upsert vetted rows into price_history.
  const db = createClient(supabaseUrl, serviceRole);
  void db; // Used by the ingestion implementation after parsing/validation.
  return new Response(JSON.stringify({
    status: "received_not_imported",
    symbol,
    message: "TinyFish response received. Implement SSE parsing, raw import storage, validation, and price_history upsert before using this pipeline.",
    responseLength: rawText.length
  }), { headers: { "content-type": "application/json" }, status: 501 });
});
